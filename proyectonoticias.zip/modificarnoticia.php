<?php 
include("conectaBase.php"); // Incluimos nuestro archivo de conexión con la base de datos 
$sql =" SELECT * FROM noticias";
 $Consulta=mysqli_query($conexion,$sql); 
while($columna_MostrarTitulos =mysqli_fetch_array($Consulta)) // Muestre los títulos de las noticias, utilizando while. 
{ 
    echo $columna_MostrarTitulos['titulo'].'  <a href="?actualizar='.$columna_MostrarTitulos['id'].'">Actualizar</a>  <a href="?eliminar='.$columna_MostrarTitulos['id'].'">eliminar</a> <br />';  // Mostramos el titulo y un enlace para eliminar la noticia 
}
  
if(isset($_POST['modificar'])) // Si el boton de "modificar" fúe presionado ejecuta el resto del código 
{ 
    $id = trim($_POST['id']); 
     $tipo = trim($_POST['tipo']); 
    $titulo = trim($_POST['titulo']); 
    $texto = trim($_POST['texto']); 
    $autorr = trim($_POST['autor']); 
    $sql2 =" UPDATE noticias SET titulo = '$titulo', fecha = NOW(), texto = '$texto', autor='$autorr',likes=0,TIPO='$tipo' WHERE id = '$id'";
    $Consulta2=mysqli_query($conexion,$sql2);
  
    if( $Consulta2) 
    { 
        echo 'La noticia se modificó corectamente'; // Si la consulta se ejecutó bien, muestra este mensaje 
    } 
    else 
    { 
        echo 'La noticia no se modificó'; // Si la consulta no se ejecutó bien, muestra este mensaje 
    } 
} 
  
if(isset($_GET['actualizar'])) 
{ 
    $id_noticia = $_GET['actualizar']; // Recibimos el id de la noticia por medio de GET 

    $sql3 =" SELECT * FROM noticias WHERE id = '$id_noticia' LIMIT 1";
    $Consulta3=mysqli_query($conexion,$sql3);
    $columna_MostrarNoticia = mysqli_fetch_array($Consulta3); 
    echo ' 
    <form action="modificarnoticia.php" method="post"> <!-- Creamos el formulario, utilizando la etiqueta form, cuyo atributo action="" indicará donde se procesará el formulario --> 
        Título de la noticia: <input name="titulo" type="text" value="'.$columna_MostrarNoticia['titulo'].'" /> <br /> 
        Texto de la noticia:  <textarea name="texto">'.$columna_MostrarNoticia['texto'].'</textarea> <br /> 
       Autor de la noticia: <input name="autor" type="text" value="'.$columna_MostrarNoticia['autor'].'" /> <br /> 
        Tipo de la noticia: <input name="tipo" type="text" value="'.$columna_MostrarNoticia['TIPO'].'" /> <br /> 
        <input type="hidden" name="id" value="'.$columna_MostrarNoticia['id'].'" /> <!-- Creamos un campo de texto oculto para pasar el id de la noticia --> 
        <input type="submit" name="modificar" value="Modificar noticia" /> 
    </form> 
    '; 
}
if(isset($_GET['eliminar'])) 
{ 
    $id=$_GET['eliminar'];
    $sql2 ="DELETE FROM noticias WHERE id = '$id'";
    $query_eliminar=mysqli_query($conexion,$sql2); 
     
    if($query_eliminar) 
    { 
        echo 'La noticia se eliminó corectamente'; // Si la consulta se ejecutó bien, muestra este mensaje 
    } 
    else 
    { 
        echo 'La noticia no se eliminó'; // Si la consulta no se ejecutó bien, muestra este mensaje 
    } 
}
?> 