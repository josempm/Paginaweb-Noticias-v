<!DOCTYPE html>
<html>
    <head>
    	<title>Admin</title>
    	<link rel="stylesheet" href="css/vernoticiass.css">
    </head>
    <body>
        <div class="foot">
        <div class="fondo">
            <a class="navbar-brand" href="index.php"><img src="log.png" width="100" height="100">  </a>    
        
            <div class"menu">
                <div class"uno">  <h1>Todas las noticias</h1> </div>
                
            </div>
        </div>
        
        </div>
 
        <div>
             <div class="form">
            <div class="dos"> <p><a href="insertanoticia.html">INSERTAR NOTICIA</a></p>  </div>
                        <?php 
            include("conectaBase.php"); // Incluimos nuestro archivo de conexión con la base de datos 
            $sql =" SELECT * FROM noticias";
             $Consulta=mysqli_query($conexion,$sql); 
            while($columna_MostrarTitulos =mysqli_fetch_array($Consulta)) // Muestre los títulos de las noticias, utilizando while. 
            { 
                /* echo '<table border="1"> <tr> <th>'.  $columna_MostrarTitulos['titulo'].' </th>                                                <th> '.  $columna_MostrarTitulos['autor'].' </th> </tr>
                        </table>
                        <a href="?actualizar='.$columna_MostrarTitulos['id'].'">  Actualizar</a>  <a href="?eliminar='.$columna_MostrarTitulos['id'].'">eliminar</a> <br />';  */ 
                    echo '<div class="listado">
                            <div> '.  $columna_MostrarTitulos['titulo'].' </div>
                            <div>Autor: '.  $columna_MostrarTitulos['autor'].'</div>
                            <div><a href="?actualizar='.$columna_MostrarTitulos['id'].'">  Actualizar</a>  <a href="?eliminar='.$columna_MostrarTitulos['id'].'">eliminar</a> <br /></div>
                          </div>';
            }
              
            if(isset($_POST['modificar'])) // Si e
            { 
                $id = trim($_POST['id']); 
                 $tipo = trim($_POST['tipo']); 
                $titulo = trim($_POST['titulo']); 
                $texto = trim($_POST['texto']); 
                $imagen = trim($_POST['imagen']);
                $autor = trim($_POST['autor']);
                $sql2 =" UPDATE noticias SET titulo = '$titulo', fecha = NOW(), texto = '$texto', autor='$autor',likes=0,TIPO='$tipo',img='$imagen' WHERE id = '$id'";
                $Consulta2=mysqli_query($conexion,$sql2);
              
                if( $Consulta2) 
                { 
                    echo 'La noticia se modificó corectamente'; 
                } 
                else 
                { 
                    echo 'La noticia no se modificó'; 
                } 
            } 
              
            if(isset($_GET['actualizar'])) 
            { 
                $id_noticia = $_GET['actualizar']; // Rec 
            
                $sql3 =" SELECT * FROM noticias WHERE id = '$id_noticia' LIMIT 1";
                $Consulta3=mysqli_query($conexion,$sql3);
                $columna_MostrarNoticia = mysqli_fetch_array($Consulta3); 
                echo ' 
                <div class="frm">
                <form action="vernoticias.php" method="post">
                
                    Título de la noticia: <input name="titulo" type="text" value="'.$columna_MostrarNoticia['titulo'].'" /> <br/> 
                    
                   Autor de la noticia: <input name="autor" type="text" value="'.$columna_MostrarNoticia['autor'].'" /> <br/> 
                   Imagen: <input name="imagen" type="text" value="'.$columna_MostrarNoticia['img'].'" /> <br/> 
                   Texto de la noticia:  <textarea name="texto">'.$columna_MostrarNoticia['texto'].'</textarea> <br /> 
                    <select name="tipo">
                    <option value="deportes">Deportes</option>
                    <option value="cultural">Cultural</option>
                    <option value="politica">Politica</option>
                    <input type="hidden" name="id" value="'.$columna_MostrarNoticia['id'].'" /> 
                    <input type="submit" name="modificar" value="Modificar noticia" /> 
                    
                </form> 
                </div>
                '; 
            }
            if(isset($_GET['eliminar'])) 
            { 
                $id=$_GET['eliminar'];
                $sql2 ="DELETE FROM noticias WHERE id = '$id'";
                $query_eliminar=mysqli_query($conexion,$sql2); 
                 
                if($query_eliminar) 
                { 
                 echo 'La noticia se eliminó corectamente'; // S 
                //    header("Location: vernoticias.php");
                } 
                else 
                { 
                    echo 'La noticia no se eliminó'; // Si la  
                } 
            }
            ?>
        </div>
        
    </div>
    </body>
</html>
 