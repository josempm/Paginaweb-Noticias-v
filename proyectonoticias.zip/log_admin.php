
<!DOCTYPE html>
<html>
<head>
	<?php
	 ?>
	<title>Log_in_Admi</title>
	<link rel="stylesheet" href="css/stylesform.css">
</head>
<body>
 <div class="from">
     <a class="navbar-brand" href="index.php">
     <img src="log.png" width="200" height="200">
  </a>
    
     <h1><p style = "font-family:cambria;"></p>VICIO</p></h1>
 	<form action="check_admin.php" method="POST">
 		<div class="info">
 			<p>Usuario</p>
			<input type="text" name="usuario" id="usuario" placeholder="Usuario" required>
			<br>
			<p>Constraseña</p>
			<input type="password" name="password" id="password" placeholder="Password" required>
			<br>
		</div>
		<div class="boton">
			<input type="submit" name="login" value="Ingresar">
		</div>
 	</form>
 </div>
</body>
</html>