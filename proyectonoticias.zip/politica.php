<!DOCTYPE html>
<html>
<head>
	<title>Politica</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<link rel="stylesheet" href="css/stylesss.css">
</head>
<body>
    <!-- Image and text -->
<nav class="navbar navbar-dark bg-primary ">
  <a class="navbar-brand" href="index.php">
    <img src="log.png" width="50" height="50" class="d-inline-block align-top" alt="">
    <strong><em>VICIO</em></strong>
  </a>
</nav>
<nav class="navbar navbar-expand-lg  navbar-dark bg-primary ">
    
  <a class="navbar-brand" href="index.php">Inicio</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="deportes.php"><strong>Deportes</strong></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="politica.php"><strong>Politica</strong></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="cultura.php"><strong>Cultural</strong></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <strong>Administrador</strong>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="log_admin.php">login</a>
          
        </div>
      </li>
      
    </ul>
  
  </div>
</nav>
<div class="cuerpo">
    <div>
        <div>
     <?php 
    include("conectaBase.php"); // Incluimos nuestro archivo de conexión con la base de datos 
    
       
     if(isset($_GET['noticia'])) 
    { 
        if(!empty($_GET['noticia'])) // Si el valor de "noticia" no es NULL, continua con el proceso 
        { 
            
            $id_noticia=$_GET['noticia'];
            $sql2 ="SELECT * FROM noticias WHERE id = '$id_noticia'";
            $query_noticias=mysqli_query($conexion,$sql2); 
           // if(mysqli_fetch_array($query_noticias) > 0) // Si existe la noticia, la muestra 
          //  { 
                while($columna = mysqli_fetch_array($query_noticias)) // Realizamos un bucle que muestre todas las noticias, utilizando while. 
              { 
                  echo ' <div class="noticia2">
                <div class="titulof2">    
                    <div><h4>'.$columna['titulo'].'</h4></div>
                    <div>Fecha: '.$columna['fecha'].'</div>
                     <div>Autor: '.$columna['autor'].'</div>
                     
                  
                </div>
                 <div><img src="'.$columna['img'].'" width="500px" ></div>
                <div>'.$columna['texto'].'</div>
                <div><a href="politica.php">Atras</a></div> 
            </div>'; /*
                    echo ' 
                    <table> 
                        <tr> 
                            <td>'.$columna['titulo'].'</td> 
                            <td>'.$columna['fecha'].'</td> 
                        </tr> 
                        <tr> 
                            <td colspan="2">'.$columna['texto'].'</td> 
                        </tr> 
                        <tr> 
                            <td><a href="politica.php">Atrás</a></td> 
                        </tr> 
                    </table> 
                    '; */
                    
              } 
              echo'<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
                <form class="form-horizontal" method="post" action="insertac.php?id='.$id_noticia.'" >
                    <fieldset>
                        
                       
                       

                        

                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-pencil-square-o bigicon"></i></span>
                            <div class="col-md-8">
                                <textarea class="form-control" id="message" name="message" placeholder="Escriba su mensaje." rows="7"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="anadir">Submit</button>
                                
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
 <form class="form-horizontal" method="post" action="like.php?id='.$id_noticia.'" >
 <button type="submit" class="btn btn-primary btn-lg" name="anadir1">like</button></form>'
;

             
           // } 
           // else 
           // { 
           //     echo 'La noticia que solicitas, no existe.'; // Si no, muestra un error 
           // } 
        } 
        else 
        { 
            echo 'Debes seleccionar una noticia.'; // Si GET no recibe ningún valor, muestra un error 
        } 
    } 
    else 
    { 
         $sql ="SELECT  * FROM noticias WHERE tipo='politica'  ORDER BY Likes DESC LIMIT 9";
            $query_noticias=mysqli_query($conexion,$sql); 
        
        $limite = 100; 
        while($columna = mysqli_fetch_array($query_noticias)) // Realizamos un bucle que muestre todas las noticias, utilizando while. 
        { 
            echo ' <div class="noticia">
                <div class="titulof">    
                    <div>'.$columna['titulo'].'</div>
                    <div><img src="'.$columna['img'].'"  width="200" "></div>
                    <div><a href="?noticia='.$columna['id'].'">Leer más</a></div> 
                </div>
               
                
            </div>'; 
        } 
    } 
    /*<table> 
                <tr> 
                    <td>'.$columna['titulo'].'</td> 
                    <td>'.$columna['fecha'].'</td> 
                </tr> 
                <tr> 
                    <td colspan="2">'.substr($columna['texto'], 0, $limite).' [...]</td> 
                </tr> 
                <tr> 
                    <td colspan="2"><a href="?noticia='.$columna['id'].'">Leer más</a></td> 
                </tr> 
            </table> */
    ?>   
    
</div>
    </div>
<div class="nrecent">
       <?php
       $sql3 ="SELECT  * FROM noticias  ORDER BY fecha DESC LIMIT 6";
            $query_noticias=mysqli_query($conexion,$sql3); 
        
      
        while($columna = mysqli_fetch_array($query_noticias)) // Realizamos un bucle que muestre todas las noticias, utilizando while. 
        { 
            echo ' <div >
                <div >    
                    <div>'.$columna['titulo'].'</div>
                    <div>'.$columna['fecha'].'</div> 
                    <div><a href="?noticia='.$columna['id'].'">Leer más</a></div><p></p>
                </div>
               
                
            </div>'; 
        } 
       ?>
    </div>  
</div>


	<div class="social">
		<a href="https://es-la.facebook.com"><img src="img/facebook.png" alt="facebook" width="40px" heigth="40px"></a>
		<a href="https://twitter.com/?lang=es"><img src="img/twitter.png" alt="twitter"width="40px" heigth="40px"></a>
		<a href="https://www.instagram.com/?hl=es-la"><img src="img/instagram.png" alt="instagram"width="40px" heigth="40px"></a>
	</div>

<!-- Footer -->
<footer class="page-footer font-small indigo">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:PepeRRe
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>