<?php 

  
$db_host = "localhost";                  
$db_name = "id12513405_noticias";                    
$db_user = "id12513405_notivicio";                   
$db_password = "pepeerre";               
$db_table = "noticias";         
$conexion = mysql_connect($db_host, $db_user, $db_password) or die("No se ha podido realizar la conexión con la base de datos. Error:".mysql_error()); 
mysql_select_db($db_name, $conexion); 
  
?> 
