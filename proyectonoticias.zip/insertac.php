<?php 
include("conectaBase.php"); 
$db_table="noticias";
if(isset($_POST['anadir'])) // Si el boton de "añadir" fué presionado ejecuta el resto del código 
{ 
        $idd = $_GET['id'];
       $mensaje = trim($_POST['message']); 
    if(!empty($mensaje) ) // Comprobamos que los valores recibidos no son NULL 
    { 
        
        $sql =" INSERT INTO `comentarios` (`id`,`comentario`,`id_noticia`) VALUES (NULL,'$mensaje','$idd')";
        if(mysqli_query($conexion,$sql)) 
        { 
            
       // echo 'La nsrbsboticia no pudo ser insertada en la base de datos'; 
         header("Location: index.php");
        } 
        else 
        { 
            echo 'La noticia no pudo ser insertada en la base de datos'; 
        } 
    } 
    else 
    { echo"<a href='main.php'>Atras</a>";
        echo 'Los campos no pueden estar vacios. Rellénalos para insertar la noticia en la base de datos'; 
    } 
} 
  
?> 