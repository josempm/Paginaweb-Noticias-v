<?php 
include("conectaBase.php"); // Incluimos nuestro archivo de conexión con la base de datos 
$sql =" SELECT * FROM noticias";
 $Consulta=mysqli_query($conexion,$sql); 
while($columna_MostrarTitulos =mysqli_fetch_array($Consulta)) // Realizamos un bucle que muestre los títulos de las noticias, utilizando while. 
{ 
    echo $columna_MostrarTitulos['titulo'].' - <a href="?noticia='.$columna_MostrarTitulos['id'].'">Eliminar</a> <br />';  // Mostramos el titulo y un enlace para eliminar la noticia 
} 
  
if(isset($_GET['noticia'])) 
{ 
    $id=$_GET['noticia'];
    $sql2 ="DELETE FROM noticias WHERE id = '$id'";
    $query_eliminar=mysqli_query($conexion,$sql2); 
     
    if($query_eliminar) 
    { 
        echo 'La noticia se eliminó corectamente'; // Si la consulta se ejecutó bien, muestra este mensaje 
    } 
    else 
    { 
        echo 'La noticia no se eliminó'; // Si la consulta no se ejecutó bien, muestra este mensaje 
    } 
} 
?>