<?php 
include("conectaBase.php"); 
$db_table="noticias";
if(isset($_POST['añadir'])) // Si el boton de "añadir" fué presionado ejecuta el resto del código 
{ 
    $titulo = trim($_POST['titulo']); 
    $texto = trim($_POST['texto']);   
     $autor = trim($_POST['autor']);   
      $tipo = trim($_POST['tipo']); 
       $imagen = trim($_POST['imagen']); 
    if(!empty($titulo) && !empty($texto) && !empty($autor) && !empty($tipo)) // Comprobamos que los valores recibidos no son NULL 
    { 
        
        $sql =" INSERT INTO `noticias` (`id`, `titulo`, `fecha`, `texto`, `likes`, `autor`,`TIPO`,`img`) VALUES (NULL,'$titulo',NOW(),'$texto',0,'$autor','$tipo','$imagen')";
        if(mysqli_query($conexion,$sql)) 
        { 
            
        
            header("Location: vernoticias.php");
        } 
        else 
        { 
            echo 'La noticia no pudo ser insertada en la base de datos'; 
        } 
    } 
    else 
    { echo"<a href='insertanoticia.html'>Atras</a>";
        echo 'Los campos no pueden estar vacios. Rellénalos para insertar la noticia en la base de datos'; 
    } 
} 
  
?> 