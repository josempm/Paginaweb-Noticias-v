<?php

//coneccion con la base de datos
$servername = "localhost";
$username = "id12513405_notivicio";
$password = "pepeerre";
$database = "id12513405_noticias";

$conexion = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conexion) {
    die("Connection failed: " . mysqli_connect_error());
}
?>