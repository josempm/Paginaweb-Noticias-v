<?php 

$servername = "localhost";
$username = "id12513405_notivicio";
$password = "pepeerre";
$database = "id12513405_noticias";

try
{
	$base = new PDO("mysql:host=$servername; dbname=$database","$username","$password");
	$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql="SELECT * FROM administrador WHERE Usuario= :usuario AND Password= :password";
	$resultado=$base->prepare($sql);
	$usuario=htmlentities(addslashes($_POST["usuario"])); //2
	$password=htmlentities(addslashes($_POST["password"]));  
	$resultado->bindValue(":usuario",$usuario);
	$resultado->bindValue(":password",$password); 
	$resultado->execute();
	$numero_registro=$resultado->rowCount();
	if($numero_registro!=0) //3
	{
	header("location:vernoticias.php");
	}
	else
	{
		//echo"contraseña incorrecta";
		header("location:log_admin.php");
	}
}catch(Exeption $e) 
{
	die("Error: ".$e->getMessage()); 
}

 ?>


