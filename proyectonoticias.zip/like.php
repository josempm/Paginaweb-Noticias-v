<?php 
include("conectaBase.php"); 
$db_table="noticias";
if(isset($_POST['anadir1'])) // Si el boton de "añadir" fué presionado ejecuta el resto del código 
{ 
        $idd = $_GET['id'];
       
   
         $sql =" SELECT * FROM `noticias` WHERE id='$idd' ";
        $x= mysqli_query($conexion,$sql);
        $columna = mysqli_fetch_array($x);
        $y=$columna['likes'];
        //settype($y,"integer");
        
        $y=$y+1;
       settype($y,"integer");
        $sql2 =" UPDATE `noticias` SET `likes`='$y' WHERE `id`='$idd'";
        if(mysqli_query($conexion,$sql2)) 
        { 
            
       // echo 'La nsrbsboticia no pudo ser insertada en la base de datos'; 
         header("Location: index.php");
        } 
        else 
        { 
            echo 'La noticia no pudo ser insertada en la base de datos'; 
        } 
   
} 
  
?> 